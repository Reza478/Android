package com.androidhive.musicplayer;

import java.util.ArrayList;
import java.util.HashMap;
//import android.view.Window;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.view.View;
import android.database.Cursor;
import android.view.Menu;
import android.view.MenuInflater;
import android.database.MergeCursor;
import android.view.MenuItem;
import android.view.View;

import android.widget.SearchView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.SimpleAdapter;

public class PlayListActivity extends ListActivity {
	// Songs list
	private SimpleCursorAdapter mAdapter;
	private SearchView mFilter;
	public ArrayList<HashMap<String, String>> songsList = new ArrayList<HashMap<String, String>>();

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.playlist);

		ArrayList<HashMap<String, String>> songsListData = new ArrayList<HashMap<String, String>>();

		SongsManager plm = new SongsManager();
		
		this.songsList = plm.getPlayList();

		
		for (int i = 0; i < songsList.size(); i++) {
		
			HashMap<String, String> song = songsList.get(i);

		
			songsListData.add(song);
		}

		
		ListAdapter adapter = new SimpleAdapter(this, songsListData,
												R.layout.playlist_item, new String[] { "songTitle" }, new int[] {
													R.id.songTitle });

		setListAdapter(adapter);

		ListView lv = getListView();
		
		lv.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
										int position, long id) {
				
					int songIndex = position;

					
					Intent in = new Intent(getApplicationContext(),
										   AndroidBuildingMusicPlayerActivity.class);
				
					in.putExtra("songIndex", songIndex);
					setResult(100, in);
					
					finish();
				}
			});
	}
	private void refreshListView() {
		String filterStr = mFilter.getQuery().toString();
		mAdapter.changeCursor(createCursor(filterStr));
	
	}

	private Cursor createCursor(String filterStr)
	{
		// TODO: Implement this method
		return null;
	}
}

